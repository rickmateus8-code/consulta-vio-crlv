# DOCMASTER HANDOFF — INSTALLATION

Extract this ZIP directly inside:

`C:\Users\ricky\Desktop\Gemini CLI`

After extraction the structure should be:

```text
C:\Users\ricky\Desktop\Gemini CLI\
│
├── AGENTS.md
│
└── docs\
    └── engine\
        ├── DOCMASTER_ENGINE_HANDOFF.md
        ├── ENGINE_STATE.md
        ├── ENGINE_REVIEW.md
        ├── ANTIGRAVITY_REVIEWER_PROMPT.md
        └── CODEX_FIRST_MESSAGE.md
```

## Codex

Open the same repository in the Antigravity IDE where the Codex extension is installed.

Codex reads root `AGENTS.md` as repository guidance.

For the first inherited session, you may paste the contents of:

`docs/engine/CODEX_FIRST_MESSAGE.md`

## Antigravity normal / 2.0

Point the Antigravity project/workspace at the same physical folder:

`C:\Users\ricky\Desktop\Gemini CLI`

Paste the contents of:

`docs/engine/ANTIGRAVITY_REVIEWER_PROMPT.md`

into the reviewer agent once.

## Important

The two agents are not connected by Markdown in real time.

They share:
- the same repository
- Git
- `ENGINE_STATE.md`
- `ENGINE_REVIEW.md`
- the durable handoff

Codex is the writer.
Antigravity is the reviewer by default.
