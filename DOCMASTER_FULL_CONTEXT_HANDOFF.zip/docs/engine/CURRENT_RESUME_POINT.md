# CURRENT RESUME POINT — DO NOT SKIP

## Expected repository line
- branch: `checkpoint/engine-3b3d-line`
- committed HEAD: `490dac1`
- parent: `e741502`
- commit: `feat(engine): add master region projection primitives`

## Exact conversation stop point
The last completed phase was:

`PHASE 3B.8B.3C.1 — CNH REGION / MEMBERSHIP / PARITY FINAL FACT CHECK`

At that point the report stated:
- HEAD remained `490dac1`
- working tree had `4 modified + 4 untracked`
- no commit
- no push
- no deploy
- next phase: `3B.8B.3D — COMMIT CHECKPOINT`

Do NOT reconstruct those uncommitted files from this document.
Inspect the actual working tree and preserve what is present.

## Final fact-check facts reported before the stop

### Master regions reported
FRONT:
`region_cnh_front = { x:180, y:380, width:1050, height:650 }`

BACK:
`region_cnh_back = { x:180, y:1050, width:1050, height:700 }`

MRZ:
`region_cnh_mrz = { x:250, y:2180, width:1900, height:260 }`

These were reported as structurally proven, but source verification remains mandatory before commit.

### Master membership reported
FRONT: 16 concrete elements:
- elem_cnh_photo
- elem_cnh_assinatura
- elem_cnh_espelho_lateral_top
- elem_cnh_nome
- elem_cnh_primeira_habilitacao
- elem_cnh_nascimento
- elem_cnh_data_emissao
- elem_cnh_validade
- elem_cnh_acc
- elem_cnh_doc_identidade
- elem_cnh_cpf
- elem_cnh_registro
- elem_cnh_categoria
- elem_cnh_nacionalidade
- elem_cnh_nome_pai
- elem_cnh_nome_mae

BACK: 19 concrete elements:
- elem_cnh_espelho_lateral_bottom
- elem_cnh_nome_estado_extenso
- elem_cnh_observacoes
- elem_cnh_local_emissao
- elem_cnh_ass_digital_1
- elem_cnh_ass_digital_2
- elem_cnh_cat_a
- elem_cnh_cat_a1
- elem_cnh_cat_b
- elem_cnh_cat_b1
- elem_cnh_cat_c
- elem_cnh_cat_c1
- elem_cnh_cat_d
- elem_cnh_cat_d1
- elem_cnh_cat_be
- elem_cnh_cat_ce
- elem_cnh_cat_c1e
- elem_cnh_cat_de
- elem_cnh_cat_d1e

MRZ: 1:
- elem_cnh_mrz

`elem_cnh_linha_divisoria` was fact-checked as NOT a dynamic master element.

### Current reported Wallet map status
FRONT:
- 16 Wallet elements total
- 15 MASTER_DERIVED_WITH_OVERRIDE
- 1 PROFILE_ONLY (`front.photoFrame`)
- reported max effective parity delta <= 1px

BACK:
- report contains a possible accounting inconsistency:
  - it states 10 Wallet elements
  - 4 MASTER_DERIVED_WITH_OVERRIDE
  - 6 PROFILE_ONLY
  - `back.espelho` appears potentially double-counted / ambiguously named
- this discrepancy MUST be reconciled before commit

MRZ:
- 1 MASTER_DERIVED_WITH_OVERRIDE
- reported max geometry delta 0px
- 70px line spacing / centered rendering remains profile-specific raster styling

QR:
- fully excluded from region projection
- remains independent PROFILE_ONLY surface

### Propagation invariant reported
Relative override model was reported to preserve:
- master X/Y movement
- master width/height resize
- no independent absolute replacement geometry

### Media status
PHOTO/SIGNATURE frame geometry linkage is part of the projection model.
Cross-profile focal/zoom adjustment transport is NOT complete yet.
No persistence/D1 migration has been performed for this.

## Immediate next safe action
1. Audit exact current diff.
2. Resolve BACK count/linkage ambiguity.
3. Verify region structural evidence from source.
4. Verify every sourceElementId.
5. Verify no absolute replacement geometry.
6. Rerun tests/typecheck/build.
7. Stage exact files.
8. Commit only if clean.

Suggested commit:
`feat(cnh): define master regions and wallet projection map`

No push/deploy after commit.
