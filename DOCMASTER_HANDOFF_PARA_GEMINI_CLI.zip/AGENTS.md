# AGENTS.md — DocMaster Engine V1

## Mandatory startup

Before doing any work in this repository, read:

1. `docs/engine/DOCMASTER_ENGINE_HANDOFF.md`
2. `docs/engine/ENGINE_STATE.md`
3. `docs/engine/ENGINE_REVIEW.md` if it exists and is non-empty.

Then verify repository truth with Git and source before changing anything.

## Roles

Codex is the primary implementation agent for the Engine work.

The Antigravity reviewer may inspect the same repository, browser/runtime, tests and diffs, but should not normally modify source code. It records independent findings in:

`docs/engine/ENGINE_REVIEW.md`

Before important checkpoints, Codex must read the current review file and resolve any `CHANGES_REQUIRED` findings conservatively.

## Current expected resume point

Historical expected branch:

`checkpoint/engine-3b3d-line`

Latest committed checkpoint before the current uncommitted slice:

`490dac1` — `feat(engine): add master region projection primitives`

The conversation stopped after Phase `3B.8B.3C.1`, with uncommitted region/linkage work historically reported as 4 modified + 4 untracked files.

Do not recreate or discard this work from documentation. Inspect the actual working tree.

## Product invariant

The complete CNH edited through `/cnhcria` / Engine / Studio is the MASTER composition.

Wallet APP surfaces:
- FRONT
- BACK
- MRZ

must eventually derive from their corresponding MASTER sections.

Wallet QR remains independent.

Required behavior:

MASTER edit
→ PRINT updates
→ corresponding Wallet surface updates automatically

Do not introduce a second absolute Wallet geometry authority.

## Derived override invariant

`MASTER_DERIVED_WITH_OVERRIDE` must remain master-derived.

Required flow:

MASTER geometry
→ region projection
→ projected geometry
→ relative target-space override
→ effective Wallet geometry

Do not replace a master-derived element with independent absolute Wallet `x/y/width/height`.

## Git safety

Never use:
- `git reset --hard`
- `git clean -fd`
- `git restore .`
- force push
- `git add .`
- `git add -A`

Do not push, deploy, merge, switch production defaults, or perform schema/D1 migrations unless explicitly authorized.

Do not mix `/consultas` work into this Engine line.

## Source-of-truth priority

When anything conflicts:

1. current repository source
2. current Git history/diff
3. executable tests/runtime
4. committed contracts
5. `DOCMASTER_ENGINE_HANDOFF.md`
6. old reports

Repository truth wins.

## Rolling state

After important checkpoints, keep `docs/engine/ENGINE_STATE.md` concise and current.

Do not turn `ENGINE_STATE.md` into a historical log; the handoff document carries history.
