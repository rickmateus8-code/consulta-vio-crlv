# CODEX — OPTIONAL FIRST MESSAGE

Normally Codex should automatically read root `AGENTS.md`.

For the very first inherited session, you may also paste this short message:

---

Read `AGENTS.md` and all required files it points to.

Then audit the actual Git/source state before changing anything.

Expected historical resume point is committed HEAD `490dac1` with uncommitted Phase 3B.8B.3C work after it, but repository truth wins.

Do not discard existing changes.

Start by reporting:
- branch
- HEAD
- working tree
- exact modified/untracked files
- last 5 commits
- active phase inferred from source + `ENGINE_STATE.md`

Then continue according to the handoff and governance.

Do not push or deploy.
